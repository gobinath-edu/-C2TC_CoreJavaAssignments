
/**
 * Airfare interface
 */
public interface Airfare {
    double calculateAmount();
}
